# Kaiser 2 Atari Source Code

## Source code

```plain
AUTORUN.BAS (short startup stub)
KAISERII.TUR (first title screen and music)
TESTER.TUR (test of lenslock table, see handbook)
KAISER0.TUR (second title screen and music)
KAISER1.TUR (credits, setup of RAMDISK, Version for ATARI 1050 comp. drives)
XF551KL1.TUR (credits, setup of RAMDISK, Version for other drives (XF551, Emulator))
KAISER2.TUR (additional setup, choose player names)
KAISERB.TUR (trading house, 1st main part of game)
KAISER3.TUR (2nd main part, wheat and land trading)
KAISER4.TUR (3nd main part, taxes and invenstments, statusscreen)
KAISER5.TUR (special part, secret service and sabotage)
KAISER6.TUR (End of game, highscore list)
```
